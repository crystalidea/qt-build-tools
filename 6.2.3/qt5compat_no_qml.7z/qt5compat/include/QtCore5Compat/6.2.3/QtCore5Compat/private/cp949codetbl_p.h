#include "../../../../../src/core5/codecs/cp949codetbl_p.h"
