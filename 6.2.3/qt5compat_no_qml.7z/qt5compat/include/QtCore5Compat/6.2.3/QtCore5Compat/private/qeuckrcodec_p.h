#include "../../../../../src/core5/codecs/qeuckrcodec_p.h"
