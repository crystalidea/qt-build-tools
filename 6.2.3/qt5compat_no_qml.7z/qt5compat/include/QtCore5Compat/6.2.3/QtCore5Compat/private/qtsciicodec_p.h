#include "../../../../../src/core5/codecs/qtsciicodec_p.h"
