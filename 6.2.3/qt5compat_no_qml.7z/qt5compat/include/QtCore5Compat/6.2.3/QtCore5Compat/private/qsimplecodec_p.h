#include "../../../../../src/core5/codecs/qsimplecodec_p.h"
