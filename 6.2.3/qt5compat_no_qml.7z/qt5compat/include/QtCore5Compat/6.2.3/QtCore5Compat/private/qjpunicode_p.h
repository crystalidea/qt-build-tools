#include "../../../../../src/core5/codecs/qjpunicode_p.h"
