#include "../../../../../src/core5/codecs/qgb18030codec_p.h"
