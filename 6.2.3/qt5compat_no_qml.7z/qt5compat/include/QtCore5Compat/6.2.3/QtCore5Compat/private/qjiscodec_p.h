#include "../../../../../src/core5/codecs/qjiscodec_p.h"
