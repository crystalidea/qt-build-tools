#include "../../../../../src/core5/codecs/qsjiscodec_p.h"
