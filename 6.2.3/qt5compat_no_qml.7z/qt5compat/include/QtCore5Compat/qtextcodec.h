#include "../../src/core5/codecs/qtextcodec.h"
